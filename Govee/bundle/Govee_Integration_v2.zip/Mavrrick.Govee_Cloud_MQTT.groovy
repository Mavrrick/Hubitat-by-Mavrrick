library (
 author: "Mavrrick",
 category: "Govee",
 description: "GoveeCloudAPI",
 name: "Govee_Cloud_MQTT",
 namespace: "Mavrrick",
 documentationLink: "http://www.example.com/"
)

import groovy.json.JsonSlurper 

// put methods, etc. here

def mqttConnectionAttempt() {
//    mqttApiKey = '['+device.getDataValue("apiKey")+']'
//    if (debugLog) log.debug "In mqttConnectionAttempt: ${mqttApiKey}"
	if (debugLog) log.debug "In mqttConnectionAttempt"
 
	if (!interfaces.mqtt.isConnected()) {
		try {   
			interfaces.mqtt.connect("ssl://mqtt.openapi.govee.com:8883",
							   "hubitat_${getHubId()}", 
                               device.getDataValue("apiKey"), 
							   device.getDataValue("apiKey"),
                               cleanSession: true)    

			// delay for connection
			pauseExecution(1000)
            
		} catch(Exception e) {
            log.error "In mqttConnectionAttempt: Error initializing. ${e}"
			if (!interfaces.mqtt.isConnected()) disconnected()
		}
	}
    
	if (interfaces.mqtt.isConnected()) {
        if (debugLog) log.debug "In mqttConnectionAttempt: Success connecting."
		unschedule(connect)
		connected()
    } else {
        if (debugLog) log.debug "In mqttConnectionAttempt: Failure connecting."
        disconnected()
    }
}

/*
def publish(topic, payload) {
    publishMqtt(topic, payload)
}

def publishMqtt(topic, payload, qos = 0, retained = true) {
    if (!interfaces.mqtt.isConnected()) {
        mqttConnectionAttempt()
    }

    try {
        interfaces.mqtt.publish("hubitat/${getHubId()}/${topic}", payload, qos, retained)
        if (debugLog) log.debug "[publishMqtt] topic: hubitat/${getHubId()}/${topic} payload: ${payload}"
    } catch (Exception e) {
        log.error "In publishMqtt: Unable to publish message."
    }
}
*/

def subscribe(topic) {
    mqttTopic = 'GA/'+device.getDataValue("apiKey")
//    log.debug "Subscribe to: ${topic} or ${mqttTopic}"
    if (!interfaces.mqtt.isConnected()) {
        connect()
    }

    if (debugLog) log.debug "Subscribe to: ${mqttTopic}"
    interfaces.mqtt.subscribe(mqttTopic)
}

def unsubscribe(topic) {
    if (!interfaces.mqtt.isConnected()) {
        connect()
    }
    
    if (debugLog) log.debug "Unsubscribe from: hubitat/${getHubId()}/${topic}"
    interfaces.mqtt.unsubscribe("hubitat/${getHubId()}/${topic}")
}

def connect() {
    mqttConnectionAttempt()
}

def connected() {
	log.info "In connected: Connected to broker"
    sendEvent (name: "connectionState", value: "connected")
//  subscribe("${device.getDataValue("apiKey")}")
    subscribe("justtestingthis")
}

def disconnect() {
	unschedule(heartbeat)

	if (interfaces.mqtt.isConnected()) {
//		publishLwt("offline")
		pauseExecution(1000)
		try {
			interfaces.mqtt.disconnect()
			pauseExecution(500)
			disconnected()
		} catch(e) {
			log.warn "Disconnection from broker failed."
			if (interfaces.mqtt.isConnected()) {
				connected()
			}
			else {
				disconnected()
			}
			return;
		}
	} 
	else {
		disconnected()
	}
}

/*
def publishLwt(String status) {
    publishMqtt("LWT", status)
}
*/

def disconnected() {
	log.info "In disconnected: Disconnected from broker"
	sendEvent (name: "connectionState", value: "disconnected")
}

/////////////////////////////////////////////////////////////////////
// Parse
/////////////////////////////////////////////////////////////////////

def parse(String event) {
    def jsonSlurper = new JsonSlurper()     
    if (debugLog) log.debug "In parse, received a message"
    def message = interfaces.mqtt.parseMessage(event)    
    def payloadJson = jsonSlurper.parseText(message.payload)
    
    if (payloadJson.device == device.getDataValue("deviceID")) {
    
        if (debugLog) log.debug "In parse, received message: ${message}"
        if (debugLog) log.debug "In parse, payloadJson is ${payloadJson}"
        if (debugLog) log.debug "In parse, deviceid is ${payloadJson.device} capability is ${payloadJson.capabilities} "
        if (debugLog) log.debug "In parse, instance is ${payloadJson.capabilities.get(0).instance}" 
        if (debugLog) log.debug "In parse, state is ${payloadJson.capabilities.get(0).state.get(0).name}"

    mqttEventCreate(payloadJson.capabilities.get(0).instance, payloadJson.capabilities.get(0).state.get(0).name)
    } else { 
        if(debugLog) log.debug "MQTT message not for this device"
    }
}

def mqttEventCreate(instance, state){
    if (instance == 'lackWaterEvent') { 
        time = new Date().format("MM/dd/yyyy HH:mm:ss")
        createEvent(name: instance, value: time, displayed: true)
    } 
    else if (instance == 'bodyAppearedEvent') {
        if (state == "Presence") {
            createEvent(name: "presence", value: "present", displayed: true)
            createEvent(name: "motion", value: "active", displayed: true)
        } else if (state == "Absence") {
            createEvent(name: "presence", value: "not present", displayed: true)
            createEvent(name: "motion", value: "inactive", displayed: true)
            
        }
    }
}    
    

/////////////////////////////////////////////////////////////////////
// Helper Functions
/////////////////////////////////////////////////////////////////////

def normalize(name) {
    return name.replaceAll("[^a-zA-Z0-9]+","-").toLowerCase()
}

def getHubId() {
    def hub = location.hub
    def hubNameNormalized = normalize(hub.name)
    hubNameNormalized = hubNameNormalized.toLowerCase()
    return hubNameNormalized
}

def heartbeat() {
	if (interfaces.mqtt.isConnected()) {
		publishMqtt("heartbeat", now().toString())
	}				
}

def periodicReconnect() {
	if (settings?.periodicConnectionRetry) {
		if (!interfaces.mqtt.isConnected()) {
			connect()
		}
	}
}

def mqttClientStatus(status) {
	if (debugLog) log.debug "In mqttClientStatus: ${status}"
    
    if (status.substring(0,6) != "Status") {
        if (debugLog) log.debug "In mqttClientStatus: Error."
    } else {
        if (debugLog) log.debug "In mqttClientStatus: Success."    
    }
}
