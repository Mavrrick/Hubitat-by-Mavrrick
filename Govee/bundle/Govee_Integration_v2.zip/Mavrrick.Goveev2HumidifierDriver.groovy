// Hubitat driver for Govee Appliances using Cloud API
// Version 1.0.19
//
// 2022-09-12 -	Initial Driver release for Govee Appliance devices
// 2022-10-19 - Added Attributes to driver
// 2022-11-3 - Send Rate Limits to parent.
// 2022-11-5 - Added update to Switch value to On when Gear or Mode are used
// 2022-11-20 - Added a pending change condition and validation that the call was successful
// ----------- A retry of the last call will be attempted if rate limit is the cause for it failing
// 2022-11-21 Moved status of cloud api call to the it's own attribute so it can be monitored easily
// 2022-12-19 Added Actuator capbility to more easily integrate with RM
// 2023-4-4   API Key update is now possible
// 2023-4-7   Update Initialize and getDeviceStatus routine to reset CloudAPI Attribute

#include Mavrrick.Govee_Cloud_API
//#include Mavrrick.Govee_Cloud_RGB
//#include Mavrrick.Govee_Cloud_Level

metadata {
	definition(name: "Govee v2 Humidifier Driver", namespace: "Mavrrick", author: "Mavrrick") {
		capability "Switch"
		capability "Actuator"
        capability "Initialize"
        capability "Refresh"
        capability "Configuration"        
        
		attribute "gear", "number"
        attribute "mode", "number"
        attribute "cloudAPI", "string"
        attribute "online", "string" 
        attribute "connectionState", "string"
        
//		command "gear" , [[name: "Fan or Mist Speed", type: 'NUMBER', description: "Gear will adjust values for Fan speed or Misting depending on what device you have. Valid values are  "]]
        command "workingMode", [[name: "mode", type: "ENUM", constraints: [ 'Manual',      'Custom',       'Auto'], description: "Mode of device"],
                          [name: "gearMode", type: "NUMBER", description: "When Mode is 1 sets hudifier speed. When set to Auto sets desired Humidity"]]
        command "desiredHumidity", [[name: desiredHumidityValue, type: 'NUMBER', description: "Set the desired Humidity the device will try to maintain"]]

        
    }

	preferences {		
		section("Device Info") {
            input("pollRate", "number", title: "Polling Rate (seconds)\nDefault:300", defaultValue:300, submitOnChange: true, width:4) 
            input(name: "debugLog", type: "bool", title: "Debug Logging", defaultValue: false)
		}
		
	}
}

/* def parse(String description) {

} */

def on() {
         if (device.currentValue("cloudAPI") == "Retry") {
             log.error "on(): CloudAPI already in retry state. Aborting call." 
         } else {
        sendEvent(name: "cloudAPI", value: "Pending")
	    sendCommand("powerSwitch", 1 ,"devices.capabilities.on_off")
            }
}

def off() {
        if (device.currentValue("cloudAPI") == "Retry") {
             log.error "off(): CloudAPI already in retry state. Aborting call." 
         } else {
        sendEvent(name: "cloudAPI", value: "Pending")
	    sendCommand("powerSwitch", 0 ,"devices.capabilities.on_off")
            }
} 

def gear(gear){
    sendEvent(name: "cloudAPI", value: "Pending")
    sendCommand("gear", gear)
}

def workingMode(mode, gear){
    log.debug "workingMode(): Processing Working Mode command. ${mode} ${gear}"
    sendEvent(name: "cloudAPI", value: "Pending")
    switch(mode){
        case "Manual":
            modenum = 1;
        
        break;
        case "Custom":
            modenum = 2;
            gear = 0;
        break;
        case "Auto":
            modenum = 3;
        break;
    default:
    log.debug "not valid value for mode";
    break;
    }
    values = '{"workMode":'+modenum+',"modeValue":'+gear+'}'
    sendCommand("workMode", values, "devices.capabilities.work_mode")
}     



def updated() {
if (logEnable) runIn(1800, logsOff)
    retrieveStateData()
    disconnect()
	pauseExecution(1000)
    mqttConnectionAttempt()
}


def installed(){
    getDeviceState()    
    retrieveStateData() 
}

def initialize() {
    if (device.currentValue("cloudAPI") == "Retry") {
        if (debugLog) {log.error "initialize(): Cloud API in retry state. Reseting "}
        sendEvent(name: "cloudAPI", value: "Initialized")
    }
    unschedule(poll)
    if (pollRate > 0) runIn(pollRate,poll)
    mqttConnectionAttempt()
}

def logsOff() {
    log.warn "debug logging disabled..."
    device.updateSetting("logEnable", [value: "false", type: "bool"])
}

def poll() {
    if (debugLog) {log.warn "poll(): Poll Initated"}
	refresh()
}

def refresh() {
    if (debugLog) {log.warn "refresh(): Performing refresh"}
    unschedule(poll)
    if (pollRate > 0) runIn(pollRate,poll)
    getDeviceState()
    if (debugLog) runIn(1800, logsOff)
}

def configure() {
    if (debugLog) {log.warn "configure(): Driver Updated"}
    unschedule()
    if (pollRate > 0) runIn(pollRate,poll)     
    retrieveStateData()    
    if (debugLog) runIn(1800, logsOff) 
}

def mqttConnectionAttempt() {
	if (logEnable) log.debug "In mqttConnectionAttempt"
 
	if (!interfaces.mqtt.isConnected()) {
		try {   
			interfaces.mqtt.connect("ssl://mqtt.openapi.govee.com:8883",
							   "hubitat_${getHubId()}", 
                               device.getDataValue("apiKey"), 
							   device.getDataValue("apiKey"),
                              cleanSession: true)    

			// delay for connection
			pauseExecution(1000)
            
		} catch(Exception e) {
			log.error "In mqttConnectionAttempt: Error initializing."
			if (!interfaces.mqtt.isConnected()) disconnected()
		}
	}

    //if (logEnable) log.debug "In mqttConnectionAttempt: Success connecting."
    //if (logEnable) log.debug "In mqttConnectionAttempt: interfaces.mqtt.isConnected = " + interfaces.mqtt.isConnected()
    
	if (interfaces.mqtt.isConnected()) {
        if (logEnable) log.debug "In mqttConnectionAttempt: Success connecting."
		unschedule(connect)
		connected()
    } else {
        if (logEnable) log.debug "In mqttConnectionAttempt: Failure connecting."
        disconnected()
    }
}

def publish(topic, payload) {
    publishMqtt(topic, payload)
}

def publishMqtt(topic, payload, qos = 0, retained = true) {
    if (!interfaces.mqtt.isConnected()) {
        mqttConnectionAttempt()
    }

    try {
        interfaces.mqtt.publish("hubitat/${getHubId()}/${topic}", payload, qos, retained)
        if (logEnable) log.debug "[publishMqtt] topic: hubitat/${getHubId()}/${topic} payload: ${payload}"
    } catch (Exception e) {
        log.error "In publishMqtt: Unable to publish message."
    }
}


def subscribe(topic) {
    if (!interfaces.mqtt.isConnected()) {
        connect()
    }

    if (logEnable) log.debug "Subscribe to: ${topic}"
    interfaces.mqtt.subscribe("${topic}")
}

def unsubscribe(topic) {
    if (!interfaces.mqtt.isConnected()) {
        connect()
    }
    
    if (logEnable) log.debug "Unsubscribe from: hubitat/${getHubId()}/${topic}"
    interfaces.mqtt.unsubscribe("hubitat/${getHubId()}/${topic}")
}

def connect() {
    mqttConnectionAttempt()
}

def connected() {
	log.info "In connected: Connected to broker"
    sendEvent (name: "connectionState", value: "connected")
    publishLwt("online")
//	subscribe("+/+/+/set")
	subscribe("GA/87fe11f0-1fbb-44cf-843f-9fa2313cae93")
}

def disconnect() {
	unschedule(heartbeat)

	if (interfaces.mqtt.isConnected()) {
		publishLwt("offline")
		pauseExecution(1000)
		try {
			interfaces.mqtt.disconnect()
			pauseExecution(500)
			disconnected()
		} catch(e) {
			log.warn "Disconnection from broker failed."
			if (interfaces.mqtt.isConnected()) {
				connected()
			}
			else {
				disconnected()
			}
			return;
		}
	} 
	else {
		disconnected()
	}
}

def publishLwt(String status) {
    publishMqtt("LWT", status)
}

def disconnected() {
	log.info "In disconnected: Disconnected from broker"
	sendEvent (name: "connectionState", value: "disconnected")
}

/////////////////////////////////////////////////////////////////////
// Parse
/////////////////////////////////////////////////////////////////////

def parse(String event) {
    def message = interfaces.mqtt.parseMessage(event)  
    def (name, hub, device, branch, type) = message.topic.tokenize( '/' )
    
    if (logEnable) log.debug "In parse, received message: ${message}"
    
	if  (device == "sendAll") {
		if (message.payload) {
			sendAll();
		}
		return;
	}
	
    def json = new groovy.json.JsonOutput().toJson([
        device: device,
        type: type,
        value: message.payload
	])
    
    return createEvent(name: "mqtt", value: json, displayed: false)
}


/////////////////////////////////////////////////////////////////////
// Helper Functions
/////////////////////////////////////////////////////////////////////

def normalize(name) {
    return name.replaceAll("[^a-zA-Z0-9]+","-").toLowerCase()
}

def getHubId() {
    def hub = location.hub
    def hubNameNormalized = normalize(hub.name)
    hubNameNormalized = hubNameNormalized.toLowerCase()
    return hubNameNormalized
}

def heartbeat() {
	if (interfaces.mqtt.isConnected()) {
		publishMqtt("heartbeat", now().toString())
	}				
}

def periodicReconnect() {
	if (settings?.periodicConnectionRetry) {
		if (!interfaces.mqtt.isConnected()) {
			connect()
		}
	}
}

def mqttClientStatus(status) {
	if (logEnable) log.debug "In mqttClientStatus: ${status}"
    
    if (status.substring(0,6) != "Status") {
        if (logEnable) log.debug "In mqttClientStatus: Error."
    } else {
        if (logEnable) log.debug "In mqttClientStatus: Success."    
    }
}
